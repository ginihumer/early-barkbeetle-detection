package at.humer.djibarkbeetledetector.AI.Model;

public class MobileNetV2Config extends ModelConfig {
    @Override
    public String getModelFilename() {
        return "borkenkaefer_test.tflite";
    }

    @Override
    public String getLabelsFilename() {
        return "borkenkaefer_labels.txt";
    }

//    @Override
//    public int getInputWidth() {
//        return 512;
//    }

    //    @Override
//    public int getInputHeight() {
//        return 512;
//    }
//
    @Override
    public int getInputSize() {
        return getInputHeight() * getInputWidth() * getChannelsCount();
    }
//
//    @Override
//    public int getChannelsCount() {
//        return 3;
//    }

//    input is normalized as follows: (information from: https://github.com/keras-team/keras-applications/blob/master/keras_applications/mobilenet_v2.py)
//    input is scaled to be between -1 and 1
//    x /= 127.5
//    x -= 1.

    @Override
    public float getMean() {
        return 0;
    }

    @Override
    public float getStd() {
        return 1;
    }

    @Override
    public boolean isQuantized() {
        return false;
    }
}
