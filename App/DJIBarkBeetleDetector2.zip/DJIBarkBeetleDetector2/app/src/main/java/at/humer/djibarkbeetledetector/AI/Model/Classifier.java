package at.humer.djibarkbeetledetector.AI.Model;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.SystemClock;
import android.util.Log;

import org.jetbrains.annotations.NotNull;
import org.tensorflow.lite.DataType;
import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.support.common.FileUtil;
import org.tensorflow.lite.support.common.ops.NormalizeOp;
import org.tensorflow.lite.support.image.ImageProcessor;
import org.tensorflow.lite.support.image.TensorImage;
import org.tensorflow.lite.support.image.ops.ResizeOp;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class Classifier {
    // TensorFlow Lite interpreter for running inference with the tflite model
    private Interpreter tflite;

    // Configuration Class for the model
    private ModelConfig modelConfig;

    /** Labels corresponding to the output of the vision model. */
    private List<String> labels;

    /** Input image TensorBuffer. */
    private TensorImage inputImageBuffer;

    /** Output probability TensorBuffer. */
    private final TensorBuffer outputProbabilityBuffer;

    /** Processer to apply post processing of the output probability. */
    //private final TensorProcessor probabilityProcessor;


    public Classifier(Activity activity, int numThreads, ModelConfig modelConfig) {
        this.modelConfig = modelConfig;
        try {
            MappedByteBuffer tfliteModel = FileUtil.loadMappedFile(activity, modelConfig.getModelFilename());
            Interpreter.Options tfliteOptions = new Interpreter.Options();
            tfliteOptions.setNumThreads(numThreads);

            tflite = new Interpreter(tfliteModel, tfliteOptions);
            modelConfig.setTflite(tflite);

            // Loads labels out from the label file.
            labels = FileUtil.loadLabels(activity, modelConfig.getLabelsFilename());
        } catch (IOException e) {
            e.printStackTrace();
        }


        int inputTensorIndex = 0;
        DataType imageDataType = tflite.getInputTensor(inputTensorIndex).dataType(); // FLOAT32
        int outputTensorIndex = 0;
        int[] probabilityShape = tflite.getOutputTensor(outputTensorIndex).shape(); // {1, NUM_CLASSES}
        DataType probabilityDataType = tflite.getOutputTensor(outputTensorIndex).dataType();

        // Creates the input tensor.
        inputImageBuffer = new TensorImage(imageDataType);

        // Creates the output tensor and its processor.
        outputProbabilityBuffer = TensorBuffer.createFixedSize(probabilityShape, probabilityDataType);

        // Creates the post processor for the output probability.
        //probabilityProcessor = new TensorProcessor.Builder().add(new NormalizeOp(0, 1)).build();

    }

    public float[] classifyImage(@NotNull final Bitmap bitmap){
        inputImageBuffer = loadImage(bitmap);

        long startTimeForReference = SystemClock.uptimeMillis();
        tflite.run(inputImageBuffer.getBuffer(), outputProbabilityBuffer.getBuffer().rewind());
        long endTimeForReference = SystemClock.uptimeMillis();

        Log.v("time","Time to run model inference: " + (endTimeForReference - startTimeForReference));
        float[] probs = outputProbabilityBuffer.getFloatArray();
//        int maxIndex = postprocess(probs);

//        float sum = findSumWithoutUsingStream(probs);

        return probs;
    }

    public static float findSumWithoutUsingStream(float[] array) {
        float sum = 0.0f;
        for (float value : array) {
            sum += value;
        }
        return sum;
    }

//    private int postprocess(float[] outputArray) {
//        // Index with highest probability
//        int maxIndex = -1;
//        float maxProb = 0.0f;
//        for (int i = 0; i < outputArray.length; i++) {
//            if (outputArray[i] > maxProb) {
//                maxProb = outputArray[i];
//                maxIndex = i;
//            }
//        }
//        return maxIndex;
//    }

    private TensorImage loadImage(@NotNull final Bitmap bitmap) {
        // Loads bitmap into a TensorImage.
        inputImageBuffer.load(bitmap);

        // Creates processor for the TensorImage.
        //int cropSize = Math.min(bitmap.getWidth(), bitmap.getHeight());
        ImageProcessor imageProcessor =
                new ImageProcessor.Builder()
                        //.add(new ResizeWithCropOrPadOp(cropSize, cropSize))
                        .add(new ResizeOp(modelConfig.getInputWidth(), modelConfig.getInputHeight(), ResizeOp.ResizeMethod.BILINEAR))
                        //.add(new Rot90Op(numRotation))
                        .add(new NormalizeOp(modelConfig.getMean(), modelConfig.getStd()))
                        .build();
        return imageProcessor.process(inputImageBuffer);
    }
}
