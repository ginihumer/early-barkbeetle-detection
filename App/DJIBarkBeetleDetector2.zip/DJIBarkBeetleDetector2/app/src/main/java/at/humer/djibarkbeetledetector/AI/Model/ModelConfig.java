package at.humer.djibarkbeetledetector.AI.Model;

import org.tensorflow.lite.Interpreter;

public abstract class ModelConfig {

    static final int FLOAT_BYTES_COUNT = 4;
    int inputTensorIndex = 0;
    private Interpreter tflite;

    public abstract String getModelFilename();
    public abstract String getLabelsFilename();
    public abstract int getInputSize();
    public abstract float getMean();
    public abstract float getStd();
    public abstract boolean isQuantized();

    public void setTflite(Interpreter tflite){
        this.tflite = tflite;
    }

    public int getInputWidth(){
        // Reads type and shape of input and output tensors, respectively.
        int[] imageShape = tflite.getInputTensor(inputTensorIndex).shape(); // {1, height, width, channels}
        return imageShape[2];
    }
    public int getInputHeight(){
        // Reads type and shape of input and output tensors, respectively.
        int[] imageShape = tflite.getInputTensor(inputTensorIndex).shape(); // {1, height, width, channels}
        return imageShape[1];
    }
    public int getChannelsCount(){
        // Reads type and shape of input and output tensors, respectively.
        int[] imageShape = tflite.getInputTensor(inputTensorIndex).shape(); // {1, height, width, channels}
        return imageShape[3];
    }
}
