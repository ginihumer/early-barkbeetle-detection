package at.humer.djibarkbeetledetector.DJI.custom;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

import at.humer.djibarkbeetledetector.R;
import dji.ux.panel.CameraSettingAdvancedPanel;
import dji.ux.panel.CameraSettingExposurePanel;
import dji.ux.widget.controls.CameraCaptureWidget;
import dji.ux.widget.controls.CameraControlsWidget;
import dji.ux.widget.controls.ExposureSettingsMenu;
import dji.ux.widget.controls.PictureVideoSwitch;

public class CustomizedCameraControlsWidget extends CameraControlsWidget {

    //region fields
//    private CameraSettingsMenuIndicatorWidget cameraSettingsMenuIndicatorWidget;
//    private PhotoVideoSwitchWidget photoVideoSwitchWidget;
//    private CameraCaptureWidget cameraCaptureWidget;
//    private ExposureSettingsIndicatorWidget exposureSettingsIndicatorWidget;


    private PictureVideoSwitch pictureVideoSwitchWidget;
    private CameraCaptureWidget cameraCaptureWidget;
    private CameraSettingExposurePanel cameraSettingExposurePanel;
    private CameraSettingAdvancedPanel cameraSettingAdvancedPanel;


    //endregion

    public CustomizedCameraControlsWidget(Context context) {
        this(context, null, 0);
    }

    public CustomizedCameraControlsWidget(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public CustomizedCameraControlsWidget(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    @Override
    public void initView(Context context, AttributeSet attributeSet, int i) {
        final LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.customized_camera_control_widget, this);
        cameraCaptureWidget = view.findViewById(R.id.widget_camera_control_camera_capture);
        ExposureSettingsMenu ex = view.findViewById(R.id.widget_camera_control_camera_exposure_settings);
        Button menu = view.findViewById(R.id.widget_camera_control_camera_settings_menu);
        menu.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
//                CameraSettingExposurePanel cameraSettingExposurePanel = findViewById(R.id.camera_setting_exposure_panel);
//                cameraSettingExposurePanel.setVisibility(VISIBLE);
            }
        });
//        pictureVideoSwitchWidget = view.findViewById(R.id.widget_camera_control_photo_video_switch);
//        cameraSettingExposurePanel = view.findViewById(R.id.widget_camera_control_camera_exposure_settings);
//        cameraSettingAdvancedPanel = view.findViewById(R.id.widget_camera_control_camera_settings_menu);
    }

    public CameraCaptureWidget getCameraCaptureWidget(){
        return cameraCaptureWidget;
    }
}
