package at.humer.djibarkbeetledetector.DJI;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import java.util.concurrent.atomic.AtomicBoolean;

import dji.common.error.DJIError;
import dji.common.error.DJISDKError;
import dji.sdk.base.BaseComponent;
import dji.sdk.base.BaseProduct;
import dji.sdk.sdkmanager.DJISDKInitEvent;
import dji.sdk.sdkmanager.DJISDKManager;

public class DJIConnect { // this is a helper class, which handles the DJI apk part

    private AtomicBoolean isRegistrationInProgress = new AtomicBoolean(false);
    private Context applicationContext;

    private DJISDKManager.SDKManagerCallback registrationCallback = new DJISDKManager.SDKManagerCallback() {

        @Override
        public void onRegister(DJIError error) {
            isRegistrationInProgress.set(false);
            if (error == DJISDKError.REGISTRATION_SUCCESS) {
                //loginAccount(); // do we even need to log in??
                DJISDKManager.getInstance().startConnectionToProduct();

                Toast.makeText(applicationContext, "SDK registration succeeded!", Toast.LENGTH_LONG).show();
            } else {

                Toast.makeText(applicationContext,
                        "SDK registration failed, check network and retry!",
                        Toast.LENGTH_LONG).show();
            }
        }
        @Override
        public void onProductDisconnect() {
            Toast.makeText(applicationContext,
                    "product disconnect!",
                    Toast.LENGTH_LONG).show();
        }
        @Override
        public void onProductConnect(BaseProduct product) {
            Toast.makeText(applicationContext,
                    "product connect!",
                    Toast.LENGTH_LONG).show();
        }

        @Override
        public void onComponentChange(BaseProduct.ComponentKey key,
                                      BaseComponent oldComponent,
                                      BaseComponent newComponent) {
            Toast.makeText(applicationContext,
                    key.toString() + " changed",
                    Toast.LENGTH_LONG).show();

        }

        @Override
        public void onInitProcess(DJISDKInitEvent event, int totalProcess) {

        }

        @Override
        public void onDatabaseDownloadProgress(long current, long total) {

        }
    };

    public DJIConnect(Context appContext){
        this.applicationContext = appContext;

    }

//    private void loginAccount(){
//        UserAccountManager.getInstance().logIntoDJIUserAccount(applicationContext,
//                new CommonCallbacks.CompletionCallbackWith<UserAccountState>() {
//                    @Override
//                    public void onSuccess(final UserAccountState userAccountState) {
//                        Toast.makeText(applicationContext,
//                                "Login Success!",
//                                Toast.LENGTH_LONG).show();
//                    }
//                    @Override
//                    public void onFailure(DJIError error) {
//                        Toast.makeText(applicationContext,
//                                "Login Error!",
//                                Toast.LENGTH_LONG).show();
//                    }
//                });
//
//    }


    public void startSDKRegistration() {
        if (isRegistrationInProgress.compareAndSet(false, true)) {
            AsyncTask.execute(new Runnable() {
                @Override
                public void run() {
                    DJISDKManager.getInstance().registerApp(applicationContext, registrationCallback);
                }
            });
        }
    }

    public void destroy(){
        DJISDKManager.getInstance().destroy();
    }

}
