package at.humer.djibarkbeetledetector.AI;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;

import at.humer.djibarkbeetledetector.AI.Model.Classifier;
import at.humer.djibarkbeetledetector.AI.Model.MobileNetV2Config;
import at.humer.djibarkbeetledetector.R;

public class ClassificationActivity extends AppCompatActivity {

    private TextView txtPctMit, txtPctOhne;
    private ProgressBar probabilityIndicator;
    private ImageView imgViewInput;

    private Classifier classifier;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classification);

        init();
    }

    private void init(){
        Intent intent = this.getIntent();
        String filePath = intent.getStringExtra("path");

        Bitmap inputImage = BitmapFactory.decodeFile(filePath);

        txtPctMit = findViewById(R.id.txtProbabilityMit);
        txtPctOhne = findViewById(R.id.txtProbabilityOhne);
        probabilityIndicator = findViewById(R.id.probabilityIndicator);
        imgViewInput = findViewById(R.id.imageViewInput);

        imgViewInput.setImageBitmap(inputImage);

        classifier = new Classifier(this, -1, new MobileNetV2Config());

        float[] results = classifier.classifyImage(inputImage);
        txtPctMit.setText(Math.round(results[0] * 100) + "%");
        txtPctOhne.setText(Math.round(results[1] * 100) + "%");
        probabilityIndicator.setProgress(Math.round(results[0] * 100));
    }

}
