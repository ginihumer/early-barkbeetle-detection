package at.humer.djibarkbeetledetector.DJI.media;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import dji.common.error.DJIError;
import dji.common.util.CommonCallbacks;
import dji.sdk.media.MediaFile;

public class MediaAdapter extends BaseAdapter {

    private Context context;
    private List<MediaFile> mediaFileList;

    public MediaAdapter(Context context, List<MediaFile> mediaFileList){
        this.context = context;
        this.mediaFileList = mediaFileList;
    }

    @Override
    public int getCount() {
        return this.mediaFileList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Log.v("adapter", "position: " + position);
        Log.v("adapter", "position: " + mediaFileList.get(position).getFileName());
        TextView textView;
        if(convertView == null){
            textView = new TextView(context);
            textView.setLayoutParams(new GridView.LayoutParams(115,115));
            textView.setBackgroundColor(Color.RED);
        }else{
            textView = (TextView) convertView;
        }

        textView.setText(mediaFileList.get(position).getFileName());
        return textView;

//        ImageView imageView;
//        if (convertView == null) {
//            imageView = new ImageView(this.context);
//            imageView.setLayoutParams(new GridView.LayoutParams(115, 115));
//            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
//        } else {
//            imageView = (ImageView) convertView;
//        }
//

//        imageView.setImageBitmap(mediaFileList.get(position).getThumbnail());
//        return imageView;
    }
}
